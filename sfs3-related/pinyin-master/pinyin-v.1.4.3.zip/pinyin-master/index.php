<?php
	// $Id: index.php 5310 2009-01-10 07:57:56Z hami $
	header("Location: name_form2.php");

?>
