pinyin module for sfs3
